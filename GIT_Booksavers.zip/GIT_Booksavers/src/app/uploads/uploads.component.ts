import { Component, OnInit } from '@angular/core';
import { BooksService} from '../books.service';
@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.css']
})
export class UploadsComponent implements OnInit {
  user:any; books : any;
  constructor(private service: BooksService) { 
    
  }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("user"));
    this.service.getBookByUserId(JSON.stringify(this.user.userId)).subscribe((result : any) =>
    this.books = result);

  }

}
