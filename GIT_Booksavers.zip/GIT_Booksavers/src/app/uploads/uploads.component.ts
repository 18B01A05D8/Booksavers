import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.css']
})
export class UploadsComponent implements OnInit {
  userId : any; books = [];object:any;user : any;
  constructor(private service: BooksService) {
    this.userId = localStorage.getItem('userId');
    this.user = JSON.parse(localStorage.getItem('user'));
    this.books = this.user.bookList;
    console.log(this.user.bookList);
   }

  ngOnInit(): void {
  }

}