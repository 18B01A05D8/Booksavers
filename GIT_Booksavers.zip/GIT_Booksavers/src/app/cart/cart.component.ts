import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems = [];
  constructor(private service: BooksService) { 
    this.cartItems = this.service.cartItems;
  }

  ngOnInit(): void {
  }
}
