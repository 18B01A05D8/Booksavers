import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user : any;editedUser:any;decrypt_pass : any;
  password : any; password1 : any;flag : any;
  constructor(private service: BooksService) {
    this.user = JSON.parse(localStorage.getItem('user'));
   }

  ngOnInit(): void {
  }

  pass(password2 : any){
    this.decrypt_pass = this.service.decrypt(this.user.password);
    console.log(this.decrypt_pass);
    console.log(password2);
    console.log(this.password1);
    if(password2 == this.decrypt_pass){
      this.user.password = this.service.encrypt(this.password1);
    }
    else{
      alert("Current Password is wrong");
    }
  }

  update(){
    this.service.updateUser(this.user).subscribe();
  }
  
}
