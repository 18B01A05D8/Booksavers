import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  book : any; books: any;books1: any;
  flag : any;flag1 : any;emailId: any;
  book1: any; bookPrice : any;subject : any; body : any;
  bookId : any; selltype: any;types = ['sell','rent'];
  
  constructor(private router: Router,private bookService:BooksService) {
    this.book = localStorage.getItem("Books");
    this.emailId = localStorage.getItem('emailId');
  }

  ngOnInit(): void {
    this.bookService.getBookByName(this.book).subscribe( (result: any) => {console.log(result); this.books = result;this.book1 = this.books[0];
    this.flag = 1});
  }

  Books(type : any){
    this.bookService.getBookByColumns(this.book,type).subscribe( (result: any) => {console.log(result); this.books1 = result;
    this.flag1 = 1});
  }
  price(value : any){
    this.bookPrice = value;
  }

  order(bookId : any){
    
  }
}
