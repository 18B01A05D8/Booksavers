import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-images',
  templateUrl: './show-images.component.html',
  styleUrls: ['./show-images.component.css']
})
export class ShowImagesComponent implements OnInit {
  books: any;
  retrivedData : any;
  bookName : any;
  constructor(private router:Router,private service: BooksService) {
   }

  ngOnInit(): void {
    this.service.getBooks().subscribe( (result: any) => {console.log(result); this.books = result; });
  }

  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}
addToCart(book : any){
  this.service.addToCart(book);
}
}


