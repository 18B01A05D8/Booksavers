import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  emailId: any;
  user:any;
  constructor(private service: BooksService) {
    //this.imageUrl = '/assets/img/default-image.png';
    this.emailId = localStorage.getItem("email");
    
  }
  ngOnInit(){
    this.user = JSON.parse(localStorage.getItem("user"));
  }
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
        //console.log('in book.ts User ');
        //console.log(this.user);
        console.log('in book.ts Bookinform:');
        console.log(imageForm);

        
    this.service.postFile(imageForm, this.fileToUpload, this.user).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
      }
    );
  }
}
