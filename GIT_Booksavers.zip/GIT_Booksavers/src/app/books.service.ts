import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BooksService {
  private isUserLogged: any;
  secretKey = "12345";
  cartItems = [];
  bookToBeAdded: Subject<any>;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    this.bookToBeAdded = new Subject();
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any {
     return this.isUserLogged;
   }
   registerUser(user: any) {
    return this.httpClient.post('RESTAPI_BOOKSAVERS/webapi/myresource/registerUser/', user);
   }

   getUserByUserPass(user : any) {
    console.log(user);
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getUserByUserPass/'+ user.emailId + '/' + user.password);
  }
  getBookByColumns(bookName : any,selltype : any){
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getBookByColumns/'+ bookName  + '/' + selltype);
  }
  getBookByUserId(userId : any){
    console.log(userId);
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getBookByUserId/'+ userId);
  }
  getUser(userId : any) {
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getUser/'+ userId);
  }

  getUserByEmail(user : any) {
    console.log(user);
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getUserByEmail/'+ user.emailId);
  }

  getBookByName(bookName : any){
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getBookByName/'+ bookName);
  }

  
   postFile(ImageForm:any,filetoUpload: File,user: any){
     const formData: FormData = new FormData();
    
     formData.append('bookName',ImageForm.bookName);
     formData.append('categoryName',ImageForm.categoryName);
     formData.append('authorName',ImageForm.authorName);
     formData.append('bookImage',filetoUpload,filetoUpload.name);
     formData.append('bookPrice',ImageForm.bookPrice);
     formData.append('selltype',ImageForm.selltype);
     formData.append('userId',user.userId);

    console.log('Inside Service...', ImageForm.user);
    //  console.log(ImageForm.bookName);
    //  console.log(ImageForm.bookPrice);
    //  console.log(ImageForm.selltype);
    //  console.log(ImageForm.user);
    //  console.log(ImageForm);
    //  console.log(formData.get('user'));

     return this.httpClient.post('RESTAPI_BOOKSAVERS/webapi/myresource/registerBook/',formData);
   }
   getBooks(){
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getBooks');
  }


  encrypt(value : string) : string{
    return CryptoJS.AES.encrypt(value, this.secretKey.trim()).toString();
  }

  decrypt(textToDecrypt : string){
    console.log(textToDecrypt);
    return CryptoJS.AES.decrypt(textToDecrypt, this.secretKey.trim()).toString(CryptoJS.enc.Utf8);
  }
  mail(emailId : any,subject: any, body : any){
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/mail/'+ emailId + '/' + subject + '/' + body );
  }

  addToCart(book:any){
    this.bookToBeAdded.next(book);
    this.cartItems.push(book);
  }
  getForCart(){
    return this.bookToBeAdded.asObservable();
  }
  updateUser(user : any){
    return this.httpClient.post('RESTAPI_BOOKSAVERS/webapi/myresource/updateUser/', user);
  }
}

